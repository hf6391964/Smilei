#include "ProjectorAM.h"

#include "Params.h"
#include "Patch.h"

ProjectorAM::ProjectorAM( Params &params, Patch *patch )
    : Projector( params, patch )
{
}

