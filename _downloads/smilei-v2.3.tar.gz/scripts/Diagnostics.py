
# For backwards compatibility, this scripts imports the python module
import os
exec(open(os.path.dirname(os.path.abspath(__file__))+os.sep+'PythonModule'+os.sep+'Smilei'+os.sep+'__init__.py','r').read())